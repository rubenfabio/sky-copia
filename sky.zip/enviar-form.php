<?php
require("./PHPMailer_5.2.0/class.phpmailer.php");

$nome = $_POST['nome'];
$phone = $_POST['phone'];
$data_envio = date('d/m/Y');
$hora_envio = date('H:i:s');

$mail = new PHPMailer(true);
try {
	$mail->SMTPDebug = 2;
	$mail->IsSMTP();
	$mail->Host = "smtp.mailserverpro.com.br";
	$mail->SMTPAuth = true;
	$mail->Port = 587;
	$mail->isHTML(true);
	$mail->SMTPOptions = array( 'ssl' => array( 'verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true ) );
	$mail->Username = 'contato@internetfibracopeltelecom.com.br';
	$mail->Password = '%a#Ic8]0@Pr';
	$mail->SMTPSecure = "tls";
	$mail->setFrom('contato@internetfibracopeltelecom.com.br', 'Central de Vendas SKY');
	$mail->addAddress('web@wolmkt.com.br');
	$mail->Subject  = 'Nos Ligamos Pra Voce - Central de Vendas SKY';
	$mail->Body     = "
	<style type='text/css'>
	body {
	margin:0px;
	font-family:Verdane;
	font-size:12px;
	color: #666666;
	}
	a{
	color: #666666;
	text-decoration: none;
	}
	a:hover {
	color: #FF0000;
	text-decoration: none;
	}
	</style>
	  <html>
		  <table width='510' border='1' cellpadding='1' cellspacing='1' bgcolor='#CCCCCC'>
			  <tr>
				<td>
				<tr>
				   <td width='500'>Nome: $nome</td>
				</tr>
				<tr>
					<td width='320'>Telefone: <b> $phone</b></td>
				</tr>
			  </td>
			</tr>
			<tr>
			  <td>Este e-mail foi enviado em <b>$data_envio</b> às <b>$hora_envio</b></td>
			</tr>
		  </table>
	  </html>
	";

	// endere�o fisico do arquivo!
	//$mail->AddAttachment('endere�o do anexo');
	$mail->send();

	echo "<script>alert('Email enviado com sucesso!');</script>";
  	echo " <meta http-equiv='refresh' content='0;URL=index.php'>";

} catch (Exception $e) {
	echo "<script>alert('Ocorreu um erro ao enviar a mensagem.');</script>";
  
	echo " <meta http-equiv='refresh' content='0;URL=index.php'>";
}



?>
